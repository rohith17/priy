app.controller("myController", function($scope, $http) {

	$scope.getCategories = function() {

		var url = "http://localhost:8080/pms1/JsonListAllServlet?action=category";

		$http.get(url).success(function(response) {
			$scope.categories = response;
			console.log(categories);
		})
		.error(function(msg) {
			$scope.categories = msg;
		});
	};

	$scope.getSubCategories = function() {

		var url = "http://localhost:8080/pms1/JsonListAllServlet?action=subcategory";

		$http.get(url).success(function(response) {
			$scope.subcategories = response;
			console.log(subcategories);
		})
		.error(function(msg) {
			$scope.subcategories = msg;
		});
	};
	
	$scope.getSuppliers = function() {

		var url = "http://localhost:8080/pms1/JsonListAllServlet?action=supplier";

		$http.get(url).success(function(response) {
			$scope.suppliers = response;
			console.log(suppliers);
		})
		.error(function(msg) {
			$scope.suppliers = msg;
		});
	};
	
	$scope.getDiscounts = function() {

		var url = "http://localhost:8080/pms1/JsonListAllServlet?action=discount";

		$http.get(url).success(function(response) {
			$scope.discounts = response;
			console.log(discounts);
		})
		.error(function(msg) {
			$scope.discounts = msg;
		});
	};
	
	$scope.getAllProducts = function() {	
		
		$http.get('http://localhost:8080/pms1/JsonProductListServlet')
			.success(function(response){
				$scope.products=response;
			})
			.error(function(errMsg){
				$scope.products=errMsg;
			});		
	};
	
});

	




