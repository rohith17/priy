package org.cap.pms1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;
import org.cap.pms1.service.IProductService;
import org.cap.pms1.service.ProductServiceImpl;
import com.google.gson.Gson;

public class JsonListAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		
		String action = request.getParameter("action");
		
		PrintWriter out = response.getWriter();
		IProductService iProductService = new ProductServiceImpl();
		Gson myJson = new Gson();

		if (action.equalsIgnoreCase("category")) {

			response.setContentType("application/json");
			List<Category> categories = iProductService.getAllCategory();
			String categoryJson = myJson.toJson(categories);
			out.println(categoryJson);

		} else if (action.equalsIgnoreCase("subCategory")) {

			response.setContentType("application/json");
			List<SubCategory> subcategories=iProductService.getAllSubCategory(); 
			String subcategoryJson=myJson.toJson(subcategories);
			out.println(subcategoryJson);
			
		} else if (action.equalsIgnoreCase("supplier")) {

			response.setContentType("application/json");
			List<Supplier> suppliers = iProductService.getAllSuppliers();
			String supplierJson = myJson.toJson(suppliers);
			out.println(supplierJson);
			
		} else if (action.equalsIgnoreCase("discount")) {

			response.setContentType("application/json");
			List<Discount> discounts = iProductService.getAllDiscounts();
			String discountJson = myJson.toJson(discounts);
			out.println(discountJson);
		}
	}
	protected void doPost1(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

		doGet(request,response);
	}
}
		
		