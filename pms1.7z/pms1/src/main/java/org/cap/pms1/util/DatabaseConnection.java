package org.cap.pms1.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseConnection {
	
	Connection conn;
	PreparedStatement preparedStatement;

	public Connection getMySQLConnection(){
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/pms","root","India123");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return conn;		
	}
	
	public PreparedStatement getPreparedStatement(String stmt){
	
		try {
			preparedStatement=getMySQLConnection().prepareStatement(stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return preparedStatement;
	}
	public void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
