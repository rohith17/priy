package org.cap.pms1.servlets;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pms1.domain.Product;
import org.cap.pms1.service.IProductService;
import org.cap.pms1.service.ProductServiceImpl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Gson myjson=new Gson();
		
		//String action=request.getParameter("action");
		IProductService iProductService=new ProductServiceImpl();
		
		//System.out.println("Loop");
		String searchBy=request.getParameter("searchBy");
		String searchtype=request.getParameter("searchtype");
		
		//if(action.equalsIgnoreCase("Name")){
		if(searchBy.equalsIgnoreCase("search by Name")){
			Product product=iProductService.searchByProductName(searchtype);
			response.setContentType("application/json");
			String namejson=myjson.toJson(product);
						
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/DisplayProduct.html");
		}
		else if(searchBy.equalsIgnoreCase("search By Supplier Name")){
			List<Product> products=iProductService.search_By_SupplierName(searchtype);
			response.setContentType("application/json");
			String supNamelist=myjson.toJson(products);
			iProductService.storeJsonData(supNamelist);
			response.sendRedirect("");
			
		}
		
	}

}
