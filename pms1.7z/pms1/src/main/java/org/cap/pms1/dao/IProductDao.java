package org.cap.pms1.dao;

import java.util.Date;
import java.util.List;
//import java.util.Map;

import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.Product;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;

public interface IProductDao {

	public List<Category> getAllCategory();

	public List<SubCategory> getAllSubCategory();

	public List<Supplier> getAllSuppliers();

	public List<Discount> getAllDiscounts();

	public boolean addProduct(Product product);

	public List<Product> getAllProducts();

	public void updateProductName(Product product, String productName);

	void updateProductMaxRetailPrice(Product product, double max_price);

	void updateProductRating(Product product, float rating);

	void updateProductCategory(Product product, Category category);

	void updateProductExpiryDate(Product product, Date expiryDate);

	void deleteProduct(int productId);
	public void storeJson(String namejson);

	String getJson();

}
