package org.cap.pms1.servlets;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.Product;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;
import org.cap.pms1.service.IProductService;
import org.cap.pms1.service.ProductServiceImpl;


public class RetrievAndInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IProductService iProductService=new ProductServiceImpl();
		//Inserting into productList
		Product product=new Product();
		
		//requesting parameters
		String prodName=request.getParameter("pname");
		String pDesc=request.getParameter("pdesc");
		String MRP=request.getParameter("mrp");
		
		SimpleDateFormat myFormat=new SimpleDateFormat("yyyy-mm-dd");
		
		String manuFactDate=request.getParameter("manuDate");
		String expiryDate=request.getParameter("exDate");
		try {
			Date prodManf=myFormat.parse(manuFactDate);
			product.setManufacturing_date(prodManf);
			
			Date expDate=myFormat.parse(expiryDate);
			product.setExpiry_date(expDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
				
		Category category=new Category();
		String cat=request.getParameter("category");
		category.setCategory_Name(cat);		
		
		SubCategory subcategory=new SubCategory();
		String subcat=request.getParameter("subCategory");
		subcategory.setSub_category_Name(subcat);
		
		Supplier supplier=new Supplier();
		String supp=request.getParameter("supplier");
		supplier.setFirstName(supp);
		
		Discount discount=new Discount();
		String[] disc=request.getParameterValues("discount");
				
		String qnt=request.getParameter("quant");
		String rat=request.getParameter("ratings");
				 
		product.setProductName(prodName);
		product.setDescription(pDesc);
		product.setMax_retail_price(Double.parseDouble(MRP));
		product.setCategory(category);	
		product.setSubCategory(subcategory);
		product.setSupplier(supplier);
				
		List<Discount> discounts=iProductService.getAllDiscounts();
		List<Discount> discounts1=new ArrayList<>();
		int len=disc.length;
		int i=0;
		for(Discount discList:discounts){	
		
		if(i<len){
			if(discList.getDiscountName().equalsIgnoreCase(disc[i])){
				discounts1.add(discList);
				i++;
			}
			product.setDiscounts(discounts1);
		}
		}
		
		iProductService.addProduct(product);
		response.sendRedirect("pages/success.html");
		
		/*boolean flag=iProductService.addProduct(product);
		if(flag)
			response.sendRedirect("../pages/product.html");*/
		
	}
		
}


