package org.cap.pms1.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pms1.service.IProductService;
import org.cap.pms1.service.ProductServiceImpl;

public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IProductService iProductService=new ProductServiceImpl();
		
		String pId=request.getParameter("pId");
		int prodId=Integer.parseInt(pId);
	    iProductService.deleteProduct(prodId);
	    response.sendRedirect("pages/deletepage.html");
	}

}
