package org.cap.pms1.service;

//import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.Collection;
import java.util.Date;
import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.sql.Date;

import org.cap.pms1.dao.IProductDao;
import org.cap.pms1.dao.ProductDaoImplForList;
import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.Product;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;
import org.cap.pms1.util.DatabaseConnection;



public class ProductServiceImpl implements IProductService {
	
	IProductDao iProductDao = new ProductDaoImplForList();
	Product product=new Product();
	DatabaseConnection databaseConnection=new DatabaseConnection();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Supplier> getAllSuppliers() {

		return iProductDao.getAllSuppliers();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}
         
	public boolean addProduct(Product product) {
		
		return iProductDao.addProduct(product);
		

		/*
		 * Map<Integer, Product> maps = iProductDao.getAllProducts(); boolean
		 * flag = false; Set<Integer> product_IDS = maps.keySet(); int
		 * product_id_generated = generateProductId();
		 * 
		 * // Generate unique Product Id if (!maps.isEmpty()) { do {
		 * 
		 * product_id_generated = generateProductId(); for (Integer product_Id :
		 * product_IDS) { if (product_Id == product_id_generated) { flag = true;
		 * break; } } } while (flag);
		 * 
		 * } product.setProductId(product_id_generated);
		 */

	}

	/*
	 * public int generateProductId() { return (int) (Math.random() * 10000); }
	 */

	public List<Product> getAllProductList() {

		return iProductDao.getAllProducts();
	}

	/*
	 * //converting into list public List<Product> getAllProductList(){
	 * 
	 * Collection<Product> productcollection=getAllProducts(); List<Product>
	 * listproducts=new ArrayList<Product>(); for(Product products :
	 * productcollection) listproducts.add(products);
	 * 
	 * return listproducts;
	 * 
	 * }
	 */

	// search by product name
	public List<Product> searchByProductName(String productName) {

		List<Product> products = getAllProductList();
		List<Product> productlist=new ArrayList<Product>();
		
		for (Product product : products) {
			if (product.getProductName().equalsIgnoreCase(productName)) {
				productlist.add(product);
			}
		}
		return productlist;
	}
		
	// search by category name
	public List<Product> searchByCategoryName(String categoryName) {
		
		List<Product> products = getAllProductList();
		List<Product> productlist=new ArrayList<Product>();
		
		for (Product product : products) {
			if (product.getCategory().getCategory_Name().equalsIgnoreCase(categoryName)) {
				
				productlist.add(product);
			}
		}
		return productlist;
	}

	// search by ratings
	public List<Product> searchByRatings(float rating) {
		
		List<Product> productlist=new ArrayList<Product>();
		List<Product> products = getAllProductList();
		
		for (Product product : products) {
			if (product.getRatings() == rating) {
				productlist.add(product);
			}
		}
		return productlist;
	}

	// search by subcategory name
	public List<Product> searchBySubCategory(String subCategory) {
		
		List<Product> products = getAllProductList();
		List<Product> productList=new ArrayList<Product>();
		
		for (Product p : products) {
			if (p.getSubCategory().getSub_category_Name().equalsIgnoreCase(subCategory)) {
				productList.add(p);
			}
		}
		return productList;
	}

	// search by supplier name
	public List<Product> searchBySupplier(String supplierName) {
		List<Product> products = getAllProductList();
		List<Product> productlist=new ArrayList<Product>();
		
		for (Product product : products) {
			if (product.getSupplier().getFirstName().equalsIgnoreCase(supplierName)
					|| product.getSupplier().getLastName().equalsIgnoreCase(supplierName)) {
				productlist.add(product);
			}
		}
		return productlist;
	}

	//searching product id
	public Product searchProductId(int productId) {

		List<Product> products = getAllProductList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getProductId() == productId) {
				searchedProduct = product;
			}
		}
		return searchedProduct;

	}

	/*public boolean removeProduct(int productId) {
		List<Product> products = getAllProductList();
		
		 * Map<Integer, Product> searchedProduct = getAllProducts(); for
		 * (Product product : products) { if (product.getProductId() ==
		 * productId) { if (searchedProduct.remove(product.getProductId(),
		 * product)) return true; } }
		 

		databaseConnection.getMySQLConnection();
		String sql = "delete from product where productId=?";

		PreparedStatement preparedStatement = databaseConnection.getPreparedStatement(sql);
		try {
			preparedStatement.setInt(1, product.getProductId());
			int count = preparedStatement.executeUpdate();

			if (count > 0)
				System.out.println(count + "rows updated");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			databaseConnection.closeConnection();
		}

		return false;
	}
*/
	
	public void updateProductName(Product product, String productName) {
		iProductDao.updateProductName(product,productName);
		
	}
	
	public void updateProductMaxRetailPrice(Product product, double max_price) {
	
		iProductDao.updateProductMaxRetailPrice(product, max_price);
	}

	
	public void updateProductRating(Product product, float rating) {
		iProductDao.updateProductRating(product,rating);
	}

	
	public void updateProductCategory(Product product, Category category) {
		iProductDao.updateProductCategory(product,category);
	}

	
	public void updateProductExpiryDate(Product product, Date expiryDate) {
		iProductDao.updateProductExpiryDate(product,expiryDate);
		
	}


	public void deleteProduct(int productId) {
		iProductDao.deleteProduct(productId);
		
	}
	
	public void storeJson(String namejson) {
				iProductDao.storeJson(namejson);			
			}
		
		public String getJson() {
				return iProductDao.getJson();
			}


	
	/*// updating by product name
	public void updateByProductName(Product product, String pName) {
		iProductDao.updateProductName(product, pName);
	}

	// udating product name
	public List<Product> updateProductName(Product p, String pName) {

		List<Product> list = getAllProductList();
		p.setProductName(pName);
		list.add(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return list;
	}

	// updating product max retail price
	public Map<Integer, Product> updateProductMaxRetailPrice(Product p, double max) {
		Map<Integer, Product> map = getAllProductList();
		p.setMax_retail_price(max);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	// udating expiry date
	public Map<Integer, Product> updateProductExpDate(Product p, Date expiryD) {
		Map<Integer, Product> map = getAllProductList();
		p.setExpiry_date(expiryD);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	// updating product ratings
	public Map<Integer, Product> updateProductRating(Product p, float rating) {
		Map<Integer, Product> map = getAllProductList();
		p.setRatings(rating);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	// updating category
	public Map<Integer, Product> updateProductCategory(Product p, Category category) {
		Map<Integer, Product> map = getAllProductList();
		p.setCategory(category);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}
*/
}
