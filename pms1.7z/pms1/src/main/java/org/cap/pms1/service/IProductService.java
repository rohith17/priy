package org.cap.pms1.service;

import java.util.Date;
import java.util.List;
//import java.util.Map;

import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.Product;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;



public interface IProductService {
	public List<Category> getAllCategory();

	public List<SubCategory> getAllSubCategory();

	public List<Discount> getAllDiscounts();

	public List<Supplier> getAllSuppliers();

	public boolean addProduct(Product product);

	public List<Product> getAllProductList();

	public List<Product> searchByProductName(String productName);

	public List<Product> searchByCategoryName(String categoryName);

	public List<Product> searchByRatings(float rating);

	public List<Product> searchBySubCategory(String subCategory);

	public List<Product> searchBySupplier(String supplier);

	public Product searchProductId(int productId);

	void updateProductName(Product product, String productName);

	void updateProductMaxRetailPrice(Product product, double max_price);

	void updateProductRating(Product product, float rating);

	void updateProductCategory(Product product, Category category);

	void updateProductExpiryDate(Product product, Date expiryDate);

	void deleteProduct(int productId);
	/*
	 * public void updateProductName(Product p, String pName); public
	 * Map<Integer, Product> updateProductMaxRetailPrice(Product p, double max);
	 * 
	 * public Map<Integer, Product> updateProductExpDate(Product p, Date
	 * expiryD); public Map<Integer, Product> updateProductRating(Product p,
	 * float rating); public Map<Integer, Product> updateProductCategory(Product
	 * p, Category category);
	 */

	public void storeJsonData(String namejson);

}
