package org.cap.pms1.dao;

import java.util.ArrayList;
import java.util.Date;
//import java.util.HashMap;
import java.util.List;

import org.cap.pms1.domain.Category;
import org.cap.pms1.domain.Discount;
import org.cap.pms1.domain.Product;
import org.cap.pms1.domain.SubCategory;
import org.cap.pms1.domain.Supplier;
import org.cap.pms1.util.DatabaseConnection;

//import java.util.Map;
//import java.lang.Thread.State;
import java.sql.*;
//import java.time.format.DateTimeFormatterBuilder;


//import com.mysql.jdbc.Statement;

public class ProductDaoImplForList implements IProductDao {

	// Central Repositary or DB
	//Map<Integer, Product> products = new HashMap<Integer, Product>();

	DatabaseConnection databaseconnetion = new DatabaseConnection();
	PreparedStatement preparedStatement = null;
	ResultSet rs = null;

	public List<Category> getAllCategory() {
		
		List<Category> categories = new ArrayList<Category>();
		
		databaseconnetion.getMySQLConnection();
		String sql = "select * from category;";
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Category category = new Category();
				category.setCategory_Id(rs.getInt("category_Id"));
				category.setCategory_Name(rs.getString("category_Name"));
				category.setDescription(rs.getString("description"));

				categories.add(category);
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			databaseconnetion.closeConnection();
		}
		return categories;
	}

	public List<SubCategory> getAllSubCategory() {

		List<Category> categories = getAllCategory();
		List<SubCategory> sub_Categories = new ArrayList<SubCategory>();
		SubCategory sub_Category = null;
		databaseconnetion.getMySQLConnection();
		try {
			String query = "select * from subcategory";
			preparedStatement = databaseconnetion.getPreparedStatement(query);
			rs = preparedStatement.executeQuery();

			Category category = new Category();
			while (rs.next()) {
				sub_Category = new SubCategory();
				sub_Category.setSub_category_Id(rs.getInt("sub_category_Id"));
				sub_Category.setSub_category_Name(rs.getString("sub_category_Name"));

				int categoryId = rs.getInt("category_Id");

				for (Category c : categories)
					if (categoryId == c.getCategory_Id())
						category = c;

				sub_Category.setCategory(category);

				sub_Categories.add(sub_Category);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (databaseconnetion != null)
					databaseconnetion.closeConnection();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sub_Categories;
	}

	public List<Supplier> getAllSuppliers() {

		List<Supplier> suppliers = new ArrayList<Supplier>();
		
		String sql = "select * from supplier";
		preparedStatement = databaseconnetion.getPreparedStatement(sql);
		try {
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Supplier supplier = new Supplier();
				supplier.setSupplierId(rs.getInt("supplierId"));
				supplier.setFirstName(rs.getString("firstName"));
				supplier.setLastName(rs.getString("lastName"));
				supplier.setAddress(rs.getString("address"));
				supplier.setCity(rs.getString("city"));
				supplier.setState(rs.getString("state"));
				supplier.setPincode(rs.getString("pincode"));
				supplier.setContactno(rs.getString("contactno"));

				suppliers.add(supplier);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			databaseconnetion.closeConnection();
		}
		
		return suppliers;
	}

	public List<Discount> getAllDiscounts() {
		List<Discount> discounts = new ArrayList<Discount>();
				
		databaseconnetion.getMySQLConnection();
		String sql = "select * from discount";
		preparedStatement = databaseconnetion.getPreparedStatement(sql);
		try {
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Discount discount = new Discount();
				discount.setDiscountId(rs.getInt("discountId"));
				discount.setDiscountName(rs.getString("discountName"));
				discount.setDescription(rs.getString("description"));
				discount.setDiscount_percentage(rs.getDouble("discount_percentage"));
				discount.setValidThru(rs.getDate("validThru"));

				discounts.add(discount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			databaseconnetion.closeConnection();
		}

		return discounts;
	}

	public boolean addProduct(Product product) {

		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;
		
		String sql1 = "insert into product values(?,?,?,?,?,?,?,?,?,?,?)";			
		preparedStatement = databaseconnetion.getPreparedStatement(sql1);
		
		try {

			preparedStatement.setInt(1, product.getProductId());
			preparedStatement.setString(2, product.getProductName());
			preparedStatement.setString(3, product.getDescription());
			preparedStatement.setDate(4, new java.sql.Date(product.getManufacturing_date().getTime()));
			preparedStatement.setDate(5, new java.sql.Date(product.getExpiry_date().getTime()));
			preparedStatement.setDouble(6, product.getMax_retail_price());
			preparedStatement.setInt(7, product.getCategory().getCategory_Id());
			preparedStatement.setInt(8, product.getSubCategory().getSub_category_Id());
			preparedStatement.setInt(9, product.getSupplier().getSupplierId());
			preparedStatement.setInt(10, product.getQuantity());
			preparedStatement.setFloat(11, product.getRatings());
			
			int rowinserted = preparedStatement.executeUpdate();
			
			//getting product id
			String sql2="select * from product;";
			preparedStatement1 = databaseconnetion.getPreparedStatement(sql2);
			rs=preparedStatement1.executeQuery();
			int id=0;
			while(rs.next()){
				id=rs.getInt(1);
			}

			//inserting into product discount table
			String sql3 = "insert into productdiscounttable values(?,?)";
			preparedStatement2 = databaseconnetion.getPreparedStatement(sql3);
			
			List<Discount> temp = product.getDiscounts();
			
			for (Discount discounts:temp) {

				preparedStatement2.setInt(1, id);
				preparedStatement2.setInt(2, discounts.getDiscountId());				
			}
			
			int rowInserted1 = preparedStatement2.executeUpdate();
		
			//values inserted into tables
			System.out.println(rowinserted+"product inserted");
			System.out.println(rowInserted1 + " product inserted " + rowInserted1 + " discount inserted");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				databaseconnetion.closeConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return true;
	}

	public List<Product> getAllProducts() {

		List<Product> products = new ArrayList<Product>();

		DatabaseConnection databaseConnection = new DatabaseConnection();
		String sql = "select * from product;";
		databaseConnection.getMySQLConnection();
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs;
		try {
			pst1 = databaseConnection.getPreparedStatement(sql);
			rs = pst1.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setDescription(rs.getString(3));
				product.setManufacturing_date(rs.getDate(4));
				product.setExpiry_date(rs.getDate(5));
				product.setMax_retail_price(rs.getDouble(6));
				product.setQuantity(rs.getInt(10));
				product.setRatings(rs.getFloat(11));


				int categoryId = rs.getInt(7);
				List<Category> categories = getAllCategory();
				for (Category c : categories) {
					if (c.getCategory_Id() == categoryId)
						product.setCategory(c);
				}

				int subCategoryId = rs.getInt(8);
				List<SubCategory> subCategories = getAllSubCategory();
				for (SubCategory subcategory : subCategories) {
					if (subcategory.getSub_category_Id() == subCategoryId)
						product.setSubCategory(subcategory);
				}

				int supplierId = rs.getInt(9);
				List<Supplier> suppliers = getAllSuppliers();
				for (Supplier supplier : suppliers) {
					if (supplier.getSupplierId() == supplierId)
						product.setSupplier(supplier);
				}

				String sql1 = "select * from productdiscounttable where productId=?";
				pst2 = databaseConnection.getPreparedStatement(sql1);
				pst2.setInt(1, product.getProductId());
				List<Discount> discounts = new ArrayList<Discount>();
				ResultSet rs1 = null;

				rs1 = pst2.executeQuery();
				while (rs1.next()) {

					int discountId = rs1.getInt(2);
					//Discount discount = new Discount();
					for (Discount d : getAllDiscounts()) {
						if (d.getDiscountId() == discountId)
							discounts.add(d);

					}
					product.setDiscounts(discounts);
				}
				
				products.add(product);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {

			try {
				pst1.close();
				pst2.close();
				databaseConnection.closeConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return products;
			
	}

	public void updateProductName(Product product, String productName) {

		databaseconnetion.getMySQLConnection();
		String sql = "update product set productName=? where productId=?";
		
		try {
			preparedStatement=databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setString(1, productName);
			preparedStatement.setInt(2, product.getProductId());
			
			int count = preparedStatement.executeUpdate();
			if (count <= 0)
				System.out.println("product name is not updated");
			else
				System.out.println("product name updated sucessfully");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateProductMaxRetailPrice(Product product, double max_price) {

		databaseconnetion.getMySQLConnection();
		String sql = "update product set max_retail_price=? where productId=?";
		
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setDouble(1, max_price);
			preparedStatement.setInt(2, product.getProductId());
			int count =preparedStatement.executeUpdate();
			if (count <= 0)
				System.out.println("product maximum reati price is not updated");
			else
				System.out.println("product max retail price updated sucessfully");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateProductRating(Product product, float rating) {
		
		String sql = "update product set ratings=? where productId=?";
		databaseconnetion.getMySQLConnection();
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setFloat(1, rating);
			preparedStatement.setInt(2, product.getProductId());
			int count = preparedStatement.executeUpdate();
			if (count <= 0)
				System.out.println("product rating is not updated");
			else
				System.out.println("product rating updated sucessfully");

		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}

	
	public void updateProductCategory(Product product, Category category) {
		
		databaseconnetion.getMySQLConnection();
		String sql = "update product set category_Id=? where productId=?";
		
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setInt(1, category.getCategory_Id());
			preparedStatement.setInt(2, product.getProductId());
			int count = preparedStatement.executeUpdate();
			if (count <= 0)
				System.out.println("product category is not updated");
			else
				System.out.println("product category updated sucessfully");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	public void updateProductExpiryDate(Product product, Date expiryDate) {
		
		databaseconnetion.getMySQLConnection();
		String sql = "update product set expiry_date=? where productId=?";
		
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setDate(1, new java.sql.Date(expiryDate.getTime()));
			preparedStatement.setInt(2, product.getProductId());
			int count = preparedStatement.executeUpdate();
			if (count <= 0)
				System.out.println("product expiry date is not updated");
			else
				System.out.println("product expiry date updated sucessfully");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void deleteProduct(int productId) {
		databaseconnetion.getMySQLConnection();
		PreparedStatement preparedStatement1 = null;
		String sql = "delete from product where productId=?";
		String sql1 = "delete from productdiscounttable where productId=?";
		
		try {
			preparedStatement = databaseconnetion.getPreparedStatement(sql);
			preparedStatement.setInt(1, productId);
			@SuppressWarnings("unused")
			int count = preparedStatement.executeUpdate();
			
			preparedStatement1 = databaseconnetion.getPreparedStatement(sql1);
			preparedStatement1.setInt(1, productId);
			int count1 = preparedStatement1.executeUpdate();
			if (count1 <= 0)
				System.out.println("produc not found");
			else
				System.out.println("product removed sucessfully");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public void storeJson(String namejson) {
		databaseconnetion.getMySQLConnection();
				PreparedStatement preparedStatement=null;
				PreparedStatement preparedStatement2=null;
				String sql="delete from jsondata";
				String sql1="insert into jsondata values (?)";
				
				try
				{
					preparedStatement=databaseconnetion.getPreparedStatement(sql);
					preparedStatement.executeUpdate();
					preparedStatement=databaseconnetion.getPreparedStatement(sql1);
					preparedStatement2.setString(1, namejson);
					preparedStatement2.executeUpdate();
				}
				catch(SQLException e){
					e.printStackTrace();
				}				
			}
			@Override
			public String getJson() {
				databaseconnetion.getMySQLConnection();
				PreparedStatement preparedStatement=null;
				String sql="select * from jsondata";
				
				ResultSet rs=null;
				String jsonData="";
				try
				{
					preparedStatement=databaseconnetion.getPreparedStatement(sql);
					rs=preparedStatement.executeQuery();
					if(rs.next())
						jsonData=rs.getString(1);
				}
				catch(SQLException e){
					e.printStackTrace();
				}
				
				return jsonData;
			}

		}
	

